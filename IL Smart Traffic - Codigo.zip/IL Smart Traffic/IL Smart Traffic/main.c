//IL Smart Traffic
//�caro Leal da Cunha Lima
//Larissa da Silva Lima

#define F_CPU 16000000UL //Frequ�ncia de trabalho da CPU
#define BAUD 9600
#define MYUBRR F_CPU/16/BAUD-1

#define set_bit(Y,bit_x) (Y|=(1<<bit_x)) //ativa bit
#define clr_bit(Y,bit_x) (Y&=~(1<<bit_x)) //limpa bit
#define tst_bit(Y,bit_x) (Y&(1<<bit_x)) //testa bit
#define LED PD5

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

uint8_t i = 0;  /// Variavel do laco
uint8_t botao = 0;	/// Variavel do botao
int tempo = 3000; /// Variavel que controla o tempo que o sinal vermelho permanece fechado

//USART

void USART_Init(unsigned int ubrr){// Inicializacao da USART
	UBRR0H = (unsigned char)(ubrr>>8); //Ajusta a taxa de transmissao
	UBRR0L = (unsigned char)ubrr;
	UCSR0B = (1<<RXCIE0)|(1<<RXEN0)|(1<<TXEN0); //Habilita o transmissor e o receptor
	UCSR0C = (1<<USBS0)|(3<<UCSZ00); //Ajusta o formato do frame: 8 bits de dados e 2 de parada
	
	DDRC = 0xFF; //Define a porta C como saida
}


void USART_Transmit(unsigned char data)/// Envio de um frame de 5 a 8bits
{
	while(!( UCSR0A & (1<<UDRE0)));//Espera a limpeza do registr. de transmissao
	UDR0 = data; //Coloca o dado no registrador e o envia
}


unsigned char USART_Receive(void)/// Recepcao de um frame de 5 a 8bits
{
	while(!(UCSR0A & (1<<RXC0))); //Espera o dado ser recebido
	return UDR0; //Le o dado recebido e retorna
}

ISR(USART_RX_vect){
	char recebido; //char que eh enviada pelo usuario no monitor serial
	recebido = UDR0; //char armazenada no registrador UDR0
	
	if(recebido == 'a'){ //ajusta o tempo do sinal vermelho para um maior intervalo de tempo ('a'umenta)
		tempo = 5000;
	}
	if(recebido == 'p'){ //ajusta o tempo do sinal vermelho para o intervalo de tempo padrao ('p'adrao)
		tempo = 3000;
	}
	if(recebido == 'd'){ //ajusta o tempo do sinal vermelho para um menor intervalo de tempo ('d'iminui)
		tempo = 1000;
	}
	USART_Transmit(recebido);
}

/* INTERRUPCAO */
ISR(INT0_vect){ ///Interrupcao por meio do botao fisico para pedestres
	botao ^=1; //Inverte o estado do botao quando ele e pressionado
	FechaSinal(); //Chama a funcao que faz o sinal fechar
}


ISR(ANALOG_COMP_vect){///Interrupcao do Comparador Analogico
	
	if(tst_bit(ACSR,ACO))//Verifica qual mudanca ocorreu na saida do comparador
		set_bit(PORTD,LED);//O LED ficara ligado quando houver pouca luz (tensao maior no terminal positivo do comparador)
	else
		clr_bit(PORTD,LED);//O LED ficara desligado quando houver  muita luz (tensao menorr no terminal positivo do comparador)
}


void SinalAberto(){///Abre o sinal para motoristas e fecha para pedestres
	PORTB = 0b00000010; //Sinal verde
	OCR2B = 255; //Pedestre vermelho ligado
	OCR2A = 0;   //Pedestre verde desligado
}

void FechaSinal(){ ///Fecha o semaforo de veiculos e abre o de pedestres
	PORTB = 0b00000000; //Apaga sinal verde
	
	PORTB = 0b00000100; //Acende sinal amarelo
	
	SinalPedestre(); //Aciona o sinal para pedestres
	
	PORTB = 0b00000000; //Apaga sinal amarelo
	
	PORTB = 0b00010000; //Acende sinal vermelho
	Barra(); //Aciona o funcionamento da barra de LEDs
}

void SinalPedestre(){ ///Muda gradativamente o estado do semaforo para pedestres, de vermelho para verde
	for(i=0;i<25;i++){ //Laco finito para executar a oscilacao do PWM ate que um LED brilhe ate 250 e o outro apague totalmente
		OCR2B = OCR2B - 10; //Decrementa em 10 unidades o valor do LED vermelho, para que ele apague gradativamente
		OCR2A = OCR2A + 10; //Incrementa em 10 unidades o valor do LED verde, para que ele acenda gradativamente
		_delay_ms(100); //Tempo de espera entre as iteracoes do laco
	}
	OCR2B = 0; //Seta o valor do PWM do sinal verde para 0, redundancia para garantir o bom funcionamento
	OCR2A = 255; //Seta o valor do PWM do sinal vermelho para 255, redundancia para garantir o bom funcionamento
}

void Barra(){ ///Funcao que apaga sequencialmente a barra de LED enquanto durar o sinal vermelho
  /**Os PORTB correspondem a posicao de cada LED da barra no circuito.
	*0 = LED apagado e 1 = LED aceso.
	*O tempo dos delays eh controlado pelo valor enviado pelo usuario responsavel
	*via monitor serial e sao divididos por 8, pois sao 8 LEDs na barra.*/
  
	PORTC = 0b1111111;
	PORTB = 0b00110000;
	_delay_ms(tempo/8);
	PORTC = 0b0111111;
	_delay_ms(tempo/8);
	PORTC = 0b0011111;
	_delay_ms(tempo/8);
	PORTC = 0b0001111;
	_delay_ms(tempo/8);
	PORTC = 0b0000111;
	_delay_ms(tempo/8);
	PORTC = 0b0000011;
	_delay_ms(tempo/8);
	PORTC = 0b0000001;
	_delay_ms(tempo/8);
	PORTC = 0b0000000;
	_delay_ms(tempo/8);
	PORTB = 0b00000000;
	_delay_ms(tempo/8);
}

int main(void){
	
	/* GPIO */
	DDRB = ~(0); //Define todas as portas B como saida
	DDRC = ~(0); //Define todas as portas C como saida
	
	/* Interrupcao, PWM e Comparador Analogico*/
	DDRD = 0b00101000; //Define a PD2 como entrada para o botao que gera a interrupcao e PD5 e PD6 como saidas para o PWM gerado pelo Timer0
	PORTD = 0b11011111;//Habilita o pull-up das portas D
	
	EICRA= 0b00000010; //Interrupcao externa INT0 na borda de descida
	EIMSK= 0b00000001; //Habilita a interrupcao externa INT0
	
	/* TIMER */
	TCCR0A = 0b10100011; //PWM nao invertido nos pinos OC0A e OC0B
	TCCR0B = 0b00000011; //liga TC0, prescaler = 64, fpwm = f0sc/(256*prescaler) = 16MHz/(256*64) = 976Hz
	OCR0A = 0; //registrador do Timer0
	OCR0B = 0; //registrador do Timer0
	
	/*Comparador Analogico*/
	DIDR1 = 0b00000011; //desabilita as entradas digitais nos pinos AIN0 e AIN1
	ACSR = 1<<ACIE; //habilita interrup. por mudanca de estado na saida do comparador
	
	sei();//habilita todas as interrupcoes
	
	/* USART */
	USART_Init(MYUBRR);//Inicializa a USART
	
	while (1){
		SinalAberto(); //inicializa o programa com o sinal aberto para os veiculos e fechado para os pedestres
	}	
}



